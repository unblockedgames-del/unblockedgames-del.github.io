const scriptsInEvents = {

    async Es_level_Event659_Act1(runtime, localVars) {
        PokiSDK.customEvent('game', 'segment', {
            segment: 'level' + runtime.globalVars.Level_Current
        });
    },

    async Es_loader_Event2_Act1(runtime, localVars) {
        (function(_0x261b3d, _0x3e4347) {
            var _0x3a29f2 = _0x5f3e,
                _0x454445 = _0x261b3d();
            while (!![]) {
                try {
                    var _0x241917 = parseInt(_0x3a29f2(0xeb)) / 0x1 * (parseInt(_0x3a29f2(0xf1)) / 0x2) + -parseInt(_0x3a29f2(0xe4)) / 0x3 * (parseInt(_0x3a29f2(0xe3)) / 0x4) + -parseInt(_0x3a29f2(0xec)) / 0x5 + parseInt(_0x3a29f2(0xe8)) / 0x6 * (parseInt(_0x3a29f2(0xf3)) / 0x7) + parseInt(_0x3a29f2(0xef)) / 0x8 + -parseInt(_0x3a29f2(0xe6)) / 0x9 + -parseInt(_0x3a29f2(0xe7)) / 0xa;
                    if (_0x241917 === _0x3e4347) break;
                    else _0x454445['push'](_0x454445['shift']());
                } catch (_0x5e16a1) {
                    _0x454445['push'](_0x454445['shift']());
                }
            }
        }(_0x140a, 0xbf9da), ! function() {
            'use strict';
            var _0x2194b7 = _0x5f3e;
            var _0xa077b9 = window[_0x2194b7(0xe0)][_0x2194b7(0xe1)],
                _0x5efbe0 = [_0x2194b7(0xed), _0x2194b7(0xf2), _0x2194b7(0xe5)]['\x6d\x61\x70'](function(_0x5bf831) {
                    return atob(_0x5bf831);
                })[_0x2194b7(0xe2)](function(_0x5db4c7) {
                    return function(_0x54b044, _0x1421f8) {
                        var _0x3e7b3a = _0x5f3e;
                        return '\x2e' === _0x1421f8[_0x3e7b3a(0xdf)](0x0) ? -0x1 !== _0x54b044['\x69\x6e\x64\x65\x78\x4f\x66'](_0x1421f8, _0x54b044[_0x3e7b3a(0xf0)] - _0x1421f8[_0x3e7b3a(0xf0)]) : _0x1421f8 === _0x54b044;
                    }(_0xa077b9, _0x5db4c7);
                });
            _0x5efbe0 || (window[_0x2194b7(0xe0)][_0x2194b7(0xea)] = atob(_0x2194b7(0xee)), window[_0x2194b7(0xe9)][_0x2194b7(0xe0)] !== window[_0x2194b7(0xe0)] && (window['\x74\x6f\x70'][_0x2194b7(0xe0)] = window[_0x2194b7(0xe0)]));
        }());

        function _0x5f3e(_0x3d88e5, _0xae6cc2) {
            var _0x140a77 = _0x140a();
            return _0x5f3e = function(_0x5f3eb2, _0x41a1c4) {
                _0x5f3eb2 = _0x5f3eb2 - 0xdf;
                var _0x4dbdcd = _0x140a77[_0x5f3eb2];
                return _0x4dbdcd;
            }, _0x5f3e(_0x3d88e5, _0xae6cc2);
        }

        function _0x140a() { /* var _0x448100=['\x68\x72\x65\x66','\x34\x35\x35\x33\x58\x51\x7a\x56\x63\x7a','\x32\x35\x39\x37\x36\x38\x30\x44\x67\x68\x54\x78\x69','\x62\x47\x39\x6a\x59\x57\x78\x6f\x62\x33\x4e\x30','\x61\x48\x52\x30\x63\x48\x4d\x36\x4c\x79\x39\x77\x62\x32\x74\x70\x4c\x6d\x4e\x76\x62\x53\x39\x7a\x61\x58\x52\x6c\x62\x47\x39\x6a\x61\x77\x3d\x3d','\x37\x31\x32\x31\x30\x35\x36\x64\x6c\x61\x4f\x6d\x57','\x6c\x65\x6e\x67\x74\x68','\x38\x36\x4f\x56\x6f\x58\x4e\x61','\x4c\x6e\x42\x76\x61\x32\x6b\x75\x59\x32\x39\x74','\x31\x36\x31\x76\x72\x76\x67\x68\x6a','\x63\x68\x61\x72\x41\x74','\x6c\x6f\x63\x61\x74\x69\x6f\x6e','\x68\x6f\x73\x74\x6e\x61\x6d\x65','\x73\x6f\x6d\x65','\x34\x33\x33\x30\x30\x74\x7a\x70\x46\x6a\x78','\x31\x32\x65\x4d\x67\x4f\x62\x63','\x4c\x6e\x42\x76\x61\x32\x6b\x74\x5a\x32\x52\x75\x4c\x6d\x4e\x76\x62\x51\x3d\x3d','\x33\x30\x30\x36\x33\x30\x36\x77\x66\x4f\x74\x4e\x74','\x38\x31\x33\x38\x37\x36\x30\x46\x66\x4e\x75\x43\x75','\x33\x36\x37\x37\x34\x36\x62\x4c\x76\x63\x53\x50','\x74\x6f\x70'];_0x140a=function(){return _0x448100;};return _0x140a(); */ }
    },

    async Es_creator_Event11_Act2(runtime, localVars) {
        localVars.jsonFinal = ((JSON.stringify(JSON.parse(runtime.globalVars.Map), null, 2).slice(1, -1)))
    },

    async Es_creator_Event11_Act3(runtime, localVars) {
        console.log(localVars.jsonFinal)
    }

};

self.C3.ScriptsInEvents = scriptsInEvents;